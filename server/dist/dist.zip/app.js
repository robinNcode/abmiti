"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const helmet_1 = __importDefault(require("helmet"));
const cors_1 = __importDefault(require("cors"));
const compression_1 = __importDefault(require("compression"));
const express_mongo_sanitize_1 = __importDefault(require("express-mongo-sanitize"));
const morgan_1 = __importDefault(require("morgan"));
const env_1 = require("./config/env");
const logger_1 = require("./config/logger");
const errorHandler_1 = require("./shared/middleware/errorHandler");
const rateLimiter_1 = require("./shared/middleware/rateLimiter");
const notFoundHandler_1 = require("./shared/middleware/notFoundHandler");
const routes_1 = require("./routes");
// DB connections
const connection_1 = require("./infrastructure/database/mongodb/connection");
const connection_2 = require("./infrastructure/database/mysql/connection");
const app = (0, express_1.default)();
/** Flutter Web assigns a different localhost port on each debug run. */
const isLocalDevelopmentOrigin = (origin) => {
    try {
        const url = new URL(origin);
        return url.protocol === 'http:' &&
            (url.hostname === 'localhost' ||
                url.hostname === '127.0.0.1' ||
                url.hostname === '[::1]');
    }
    catch {
        return false;
    }
};
// ── Security middleware ──────────────────────────────────────
app.use((0, helmet_1.default)({
    // Allow uploaded images/assets to be embedded cross-origin
    // (page served on :5173, static files on :5000 in dev).
    crossOriginResourcePolicy: { policy: 'cross-origin' },
}));
app.use((0, cors_1.default)({
    origin: (origin, callback) => {
        // Allow server-to-server requests when no Origin is provided.
        if (!origin)
            return callback(null, true);
        // Allow local frontend origins during local testing even when the API is running in production mode.
        if (isLocalDevelopmentOrigin(origin)) {
            return callback(null, true);
        }
        if (origin && env_1.env.CLIENT_URLS.includes(origin)) {
            return callback(null, true);
        }
        callback(new Error(`CORS: origin "${origin}" is not allowed`));
    },
    credentials: true,
}));
if (env_1.env.DB_PROVIDER === 'mongodb') {
    app.use((0, express_mongo_sanitize_1.default)());
}
// ── General middleware ───────────────────────────────────────
app.use((0, compression_1.default)());
app.use(express_1.default.json({ limit: '10kb' }));
app.use(express_1.default.urlencoded({ extended: true }));
const path_1 = __importDefault(require("path"));
app.use('/public', express_1.default.static(path_1.default.join(process.cwd(), 'public')));
if (env_1.env.NODE_ENV === 'development') {
    app.use((0, morgan_1.default)('dev'));
}
// ── Rate limiting ────────────────────────────────────────────
app.use(env_1.env.API_PREFIX, rateLimiter_1.rateLimiter);
// ── Routes ───────────────────────────────────────────────────
(0, routes_1.registerRoutes)(app);
// ── Error handling ───────────────────────────────────────────
app.use(notFoundHandler_1.notFoundHandler);
app.use(errorHandler_1.globalErrorHandler);
// ── Bootstrap ───────────────────────────────────────────────
const start = async () => {
    logger_1.logger.info(`🗄️  DB provider: ${env_1.env.DB_PROVIDER}`);
    if (env_1.env.DB_PROVIDER === 'mysql') {
        await (0, connection_2.connectMySQL)();
    }
    else {
        await (0, connection_1.connectMongoDB)();
    }
    app.listen(env_1.env.PORT, () => {
        logger_1.logger.info(`🚀 abmiti server running on port ${env_1.env.PORT} [${env_1.env.NODE_ENV}]`);
    });
};
start().catch((err) => {
    logger_1.logger.error('Failed to start server', err);
    process.exit(1);
});
exports.default = app;
//# sourceMappingURL=app.js.map