"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authService = exports.signTokensForUser = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const env_1 = require("../../config/env");
const errors_1 = require("../../shared/utils/errors");
const container_1 = require("../../container");
const signTokensForUser = (user) => {
    const payload = {
        userId: String(user._id),
        email: user.email,
        userType: user.userType ?? 'user',
    };
    return {
        accessToken: jsonwebtoken_1.default.sign(payload, env_1.env.JWT_SECRET, { expiresIn: env_1.env.JWT_EXPIRES_IN }),
        refreshToken: jsonwebtoken_1.default.sign(payload, env_1.env.JWT_REFRESH_SECRET, { expiresIn: env_1.env.JWT_REFRESH_EXPIRES_IN }),
    };
};
exports.signTokensForUser = signTokensForUser;
exports.authService = {
    signTokensForUser: exports.signTokensForUser,
    async register(dto) {
        console.log(dto);
        const exists = await container_1.container.userRepo.findByEmail(dto.email);
        if (exists)
            throw new errors_1.ConflictError('Email already registered');
        const user = await container_1.container.userRepo.create({ name: dto.name, email: dto.email, password: dto.password });
        return { user, tokens: (0, exports.signTokensForUser)(user) };
    },
    async login(dto) {
        const user = await container_1.container.userRepo.findByEmail(dto.email, true);
        if (!user || !(await user.comparePassword(dto.password))) {
            throw new errors_1.UnauthorizedError('Invalid email or password');
        }
        return { user, tokens: (0, exports.signTokensForUser)(user) };
    },
    async refresh(refreshToken) {
        let payload;
        try {
            const decoded = jsonwebtoken_1.default.verify(refreshToken, env_1.env.JWT_REFRESH_SECRET);
            if (typeof decoded !== 'object' || decoded === null || Array.isArray(decoded)) {
                throw new errors_1.UnauthorizedError('Invalid refresh token');
            }
            payload = decoded;
        }
        catch {
            throw new errors_1.UnauthorizedError('Invalid refresh token');
        }
        const user = await container_1.container.userRepo.findById(payload.userId);
        if (!user)
            throw new errors_1.UnauthorizedError('User not found');
        return (0, exports.signTokensForUser)(user);
    },
    async getMe(userId) {
        const user = await container_1.container.userRepo.findById(userId);
        if (!user)
            throw new errors_1.UnauthorizedError('User not found');
        return user;
    },
    async updateMe(userId, dto) {
        if (dto.budget !== undefined) {
            const updated = await container_1.container.userRepo.updateBudget(userId, dto.budget);
            if (!updated)
                throw new errors_1.UnauthorizedError('User not found');
            return updated;
        }
        if (dto.name !== undefined || dto.avatar !== undefined) {
            const updated = await container_1.container.userRepo.updateProfile(userId, {
                name: dto.name,
                avatar: dto.avatar,
            });
            if (!updated)
                throw new errors_1.UnauthorizedError('User not found');
            return updated;
        }
        const user = await container_1.container.userRepo.findById(userId);
        if (!user)
            throw new errors_1.UnauthorizedError('User not found');
        return user;
    },
};
//# sourceMappingURL=auth.service.js.map