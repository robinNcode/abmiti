interface MonthlySummary {
    income: number;
    expense: number;
    investment: number;
    budget: number;
    remainingBudget: number;
    amountOverBudget: number;
    budgetUsed: number;
    savings: number;
    savingsRate: number;
    incomeCount: number;
    expenseCount: number;
    investmentCount: number;
    savingsCount: number;
    payableCount: number;
    receivableCount: number;
}
interface CategoryBreakdown {
    category: {
        _id: string;
        name: string;
        icon: string;
        color: string;
    };
    total: number;
    count: number;
    percentage: number;
}
interface MonthlyTrend {
    month: number;
    year: number;
    income: number;
    expense: number;
    savings: number;
    investment?: number;
}
interface YearlySummary {
    income: number;
    expense: number;
    investment: number;
    savings: number;
    savingsRate: number;
    incomeCount: number;
    expenseCount: number;
    investmentCount: number;
    savingsCount: number;
    payableCount: number;
    receivableCount: number;
}
interface AccountSummary {
    account: {
        _id: string;
        name: string;
        type: string;
        balance: number;
    };
    totalSavings: number;
    count: number;
}
export declare const summaryService: {
    monthly(userId: string, month: number, year: number, budget?: number): Promise<MonthlySummary>;
    categoryBreakdown(userId: string, month: number, year: number): Promise<CategoryBreakdown[]>;
    yearlyTrend(userId: string, year: number): Promise<MonthlyTrend[]>;
    yearly(userId: string, year: number): Promise<YearlySummary>;
    accountSummaries(userId: string, year?: number): Promise<AccountSummary[]>;
    budgetWarnings(userId: string): Promise<{
        month: number;
        year: number;
        budget: number;
        expense: number;
        overBudget: number;
    }[]>;
    categoryReport(userId: string, filters: {
        startDate: Date;
        endDate: Date;
        categoryIds?: string[];
        minAmount?: number;
        maxAmount?: number;
        type?: "income" | "expense" | "investment" | "savings" | "payable" | "receivable";
    }): Promise<{
        category: {
            _id: string;
            name: string;
            icon: string;
            color: string;
        };
        total: number;
        count: number;
        avgAmount: number;
        minAmount: number;
        maxAmount: number;
    }[]>;
    transactionStatement(userId: string, filters: {
        startDate: Date;
        endDate: Date;
        categoryIds?: string[];
        type?: "income" | "expense" | "investment" | "savings" | "payable" | "receivable";
    }): Promise<{
        _id: string;
        date: Date;
        type: import("../../shared/types").EntryType;
        amount: number;
        note: string;
        sector: string | undefined;
        category: {
            _id: string;
            name: string;
            icon: string;
            color: string;
        };
        source: string;
        account: {
            _id: string;
            name: string;
            type: string;
        } | undefined;
        runningBalance: number;
    }[]>;
};
export {};
//# sourceMappingURL=summary.service.d.ts.map