import { IUser, ICategory, ICategoryInput, IEntry, IAccount, IAccountInput, IBudget, IBudgetInput, IBudgetLineInput, IEntryFilters, IPaginationOptions, IPaginatedResult, EntryType } from './index';
export interface IUserRepository {
    findByEmail(email: string, includePassword?: boolean): Promise<IUser | null>;
    findById(id: string): Promise<IUser | null>;
    create(data: {
        name: string;
        email: string;
        password: string;
    }): Promise<IUser>;
    updateBudget(id: string, budget: number): Promise<IUser | null>;
    updateProfile(id: string, data: {
        name?: string;
        avatar?: string;
    }): Promise<IUser | null>;
    findByGoogleId(googleId: string): Promise<IUser | null>;
    createFromGoogle(data: {
        name: string;
        email: string;
        googleId: string;
        avatar?: string;
    }): Promise<IUser>;
    linkGoogleId(userId: string, googleId: string): Promise<IUser | null>;
}
export interface ICategoryRepository {
    findByUser(userId: string, type?: EntryType): Promise<ICategory[]>;
    findById(id: string): Promise<ICategory | null>;
    findByUserAndId(userId: string, id: string): Promise<ICategory | null>;
    findByNameAndType(userId: string, name: string, type: EntryType): Promise<ICategory | null>;
    insertMany(docs: (ICategoryInput & {
        user: string;
    })[]): Promise<void>;
    create(data: ICategoryInput & {
        user: string;
    }): Promise<ICategory>;
    update(id: string, data: Partial<{
        name: string;
        icon: string;
        color: string;
    }>): Promise<ICategory>;
    remove(id: string): Promise<void>;
}
export interface IEntryRepository {
    findMany(userId: string, filters: IEntryFilters, pagination: IPaginationOptions): Promise<IPaginatedResult<IEntry>>;
    findById(id: string, userId: string): Promise<IEntry | null>;
    create(data: Partial<IEntry>): Promise<IEntry>;
    update(id: string, userId: string, data: Partial<IEntry>): Promise<IEntry | null>;
    remove(id: string, userId: string): Promise<boolean>;
}
export interface IAccountRepository {
    create(data: IAccountInput & {
        user: string;
    }): Promise<IAccount>;
    findByUser(userId: string): Promise<IAccount[]>;
    findById(userId: string, accountId: string): Promise<IAccount | null>;
    update(userId: string, accountId: string, data: Partial<IAccountInput>): Promise<IAccount | null>;
    softDelete(userId: string, accountId: string): Promise<boolean>;
    updateBalance(userId: string, accountId: string, amount: number): Promise<IAccount | null>;
}
export interface IMonthlySummaryRow {
    _id: string;
    total: number;
    count: number;
}
export interface ICategoryBreakdownRow {
    _id: string;
    total: number;
    count: number;
    category: {
        _id: string;
        name: string;
        icon: string;
        color: string;
    };
}
export interface IMonthlyTrendRow {
    _id: {
        month: number;
        type: string;
    };
    total: number;
}
export interface IAccountSummaryRow {
    _id: string;
    totalSavings: number;
    count: number;
    account: {
        _id: string;
        name: string;
        type: string;
        balance: number;
    };
}
export interface ICategoryReportRow {
    _id: string;
    total: number;
    count: number;
    minAmount: number;
    maxAmount: number;
    category?: {
        _id: string;
        name: string;
        icon: string;
        color: string;
    };
}
export interface ITransactionStatementRow {
    _id: string;
    date: Date;
    type: EntryType;
    amount: number;
    note: string;
    sector?: string;
    category?: {
        _id: string;
        name: string;
        icon: string;
        color: string;
    };
    source: string;
    account?: {
        _id: string;
        name: string;
        type: string;
    };
    runningBalance: number;
}
export interface ISummaryRepository {
    getMonthlySummary(userId: string, start: Date, end: Date): Promise<IMonthlySummaryRow[]>;
    getCategoryBreakdown(userId: string, start: Date, end: Date): Promise<ICategoryBreakdownRow[]>;
    getYearlyTrend(userId: string, start: Date, end: Date): Promise<IMonthlyTrendRow[]>;
    getAccountSummaries(userId: string, year?: number): Promise<IAccountSummaryRow[]>;
    getCategoryReport(userId: string, filters: {
        startDate: Date;
        endDate: Date;
        categoryIds?: string[];
        minAmount?: number;
        maxAmount?: number;
        type?: 'income' | 'expense' | 'investment' | 'savings' | 'payable' | 'receivable';
    }): Promise<ICategoryReportRow[]>;
    getTransactionStatement(userId: string, filters: {
        startDate: Date;
        endDate: Date;
        categoryIds?: string[];
        type?: EntryType;
    }): Promise<ITransactionStatementRow[]>;
}
export interface IBudgetRepository {
    create(userId: string, data: IBudgetInput): Promise<IBudget>;
    update(id: string, userId: string, data: Partial<IBudgetInput>): Promise<IBudget | null>;
    findById(id: string, userId: string): Promise<IBudget | null>;
    findByMonth(userId: string, month: number, year: number, isTemplate?: boolean): Promise<IBudget | null>;
    findMany(userId: string, templatesOnly?: boolean): Promise<IBudget[]>;
    remove(id: string, userId: string): Promise<boolean>;
    addLine(budgetId: string, userId: string, line: IBudgetLineInput): Promise<IBudget | null>;
    updateLine(budgetId: string, lineId: string, userId: string, line: Partial<IBudgetLineInput>): Promise<IBudget | null>;
    removeLine(budgetId: string, lineId: string, userId: string): Promise<IBudget | null>;
    reorderLines(budgetId: string, userId: string, order: string[]): Promise<IBudget | null>;
    findExpenseEntriesByCategories(userId: string, categoryIds: string[], start: Date, end: Date): Promise<IEntry[]>;
}
//# sourceMappingURL=repositories.d.ts.map